<h1>Welcome <?=$nm?></h1>



